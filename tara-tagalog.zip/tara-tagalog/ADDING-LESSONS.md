# Adding lessons

Add a lesson object to a unit's `lessons` list in any `content-*.js` file. The app builds the exercises, vocabulary entries, review and progress for it.

```js
{id:"u8l5", title:"At a party", cat:"Conversation",     // id must be new and never change
 w:[ // at least 7: [tagalog, english, say-it guide, example, example english, optional details]
   ["salamat","thank you","sa-LA-mat","Salamat po.","Thank you.",{l:"literal",u:"when used",r:"register",n:"note"}],
 ],
 s:[ // at least 5: [tagalog, english, [other accepted english], [other accepted tagalog orders]]
   ["Salamat po.","Thank you.",["Thanks"]],
 ],
 b:[ // at least 2: [sentence with ___, english, answer, [3 wrong choices], explanation]
 ],
 c:[ // at least 1: [situation, speaker, line, english, [[reply, english, feedback] x3]]  first reply is correct
 ],
 g:{ // optional grammar note
   t:"Title", x:["Explanation"], e:[["Tagalog","English","Why"]], cmp:"Compared with English",
   m:[["Wrong","Right","Why"]], q:["Question","Answer",["wrong","wrong","wrong"],"Why"]
 }}
```

- The snippet shows one item per list. Meet the minimum counts.
- Use curly apostrophes (’) inside Tagalog and English text, as the existing lessons do.
- A new unit is another `COURSE.push({id, title, tl, icon, lessons:[...]})`.
- If you create a new content file, add it to `index.html` (before `store.js`) and to `FILES` in `sw.js`, and change `VERSION` there.
- Review history is matched by Tagalog text, so editing a sentence drops its pending review item.
- Check wrong choices carefully: none should also be a correct answer.
